# generated from genmsg/cmake/pkg-msg-paths.cmake.develspace.in

set(cav_msgs_MSG_INCLUDE_DIRS "/home/liuyw/桌面/avdp_path_planning_base/src/cav_msgs/msg")
set(cav_msgs_MSG_DEPENDENCIES std_msgs)
